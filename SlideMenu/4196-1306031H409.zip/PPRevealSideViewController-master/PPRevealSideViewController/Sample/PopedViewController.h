//
//  PopedViewController.h
//  PPRevealSideViewController
//
//  Created by Marian PAUL on 17/02/12.
//  Copyright (c) 2012 Marian PAUL aka ipodishima — iPuP SARL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopedViewController : UIViewController
- (IBAction)popToRoot:(id)sender;
@end
