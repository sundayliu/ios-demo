//
//  AppDelegate.h
//  MFSideMenuDemoStoryboard
//
//  Created by Michael Frederick on 3/15/13.
//  Copyright (c) 2013 Michael Frederick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
