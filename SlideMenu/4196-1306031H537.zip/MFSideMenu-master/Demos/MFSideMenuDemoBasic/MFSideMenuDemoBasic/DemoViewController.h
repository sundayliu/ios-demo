//
//  DemoViewController.h
//  MFSideMenuDemo
//
//  Created by Michael Frederick on 3/19/12.
//

#import <UIKit/UIKit.h>

@interface DemoViewController : UIViewController

- (IBAction)pushAnotherPressed:(id)sender;

@end
