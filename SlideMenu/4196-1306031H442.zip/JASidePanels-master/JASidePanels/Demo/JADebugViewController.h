//
//  JADebugViewController.h
//  JASidePanels
//
//  Created by Jesse Andersen on 10/23/12.
//
//

#import <UIKit/UIKit.h>

@interface JADebugViewController : UIViewController

@end
