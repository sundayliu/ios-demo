//
//  LeftViewController.m
//  NavigationExample
//
//  Created by Tom Adriaenssen on 30/05/12.
//  Copyright (c) 2012 Adriaenssen BVBA, 10to1. All rights reserved.
//

#import "LeftViewController.h"

@interface LeftViewController ()

@end

@implementation LeftViewController


@end
