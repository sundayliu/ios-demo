//
//  AppDelegate.h
//  FeaturesExample
//

#import <UIKit/UIKit.h>

@class ChoiceController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
