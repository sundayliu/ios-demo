//
//  RootViewController.h
//  FeaturesExample
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@property (nonatomic, retain) IBOutlet UIView* choiceView;
@property (nonatomic, retain) IBOutlet UIView* panningView;
@property (nonatomic, retain) UINavigationController* navController;

@end
