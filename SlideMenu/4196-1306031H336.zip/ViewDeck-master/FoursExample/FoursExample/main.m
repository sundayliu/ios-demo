//
//  main.m
//  FoursExample
//
//  Created by Tom Adriaenssen on 12/09/12.
//  Copyright (c) 2012 Interface Implemenation. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
