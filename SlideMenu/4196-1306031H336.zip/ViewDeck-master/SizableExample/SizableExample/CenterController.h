//
//  CenterController.h
//  SizableExample
//
//  Created by Tom Adriaenssen on 14/01/12.
//  Copyright (c) 2012 Adriaenssen BVBA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CenterController : UIViewController

@end
