//
//  ViewDeckTestingTests.m
//  ViewDeckTestingTests
//
//  Created by Tom Adriaenssen on 28/03/13.
//  Copyright (c) 2013 Tom Adriaenssen. All rights reserved.
//

#import "ViewDeckTestingTests.h"

@implementation ViewDeckTestingTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ViewDeckTestingTests");
}

@end
